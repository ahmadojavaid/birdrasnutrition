<section class="wide_section">
    <div class="narrow" >
<?php 
echo do_shortcode( '[contact-form-7 title="'.$instance['title'].'" id="'.$instance['id'].'" ]' ); ?>
    </div>
</section>