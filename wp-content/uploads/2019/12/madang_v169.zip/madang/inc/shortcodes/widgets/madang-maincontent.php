<?php 

//visibility
if ( $item['visibility'] == '' ){

global $content_main;  $content_main = true; ?>

    <main>
        <div class="container">
<?php } ?>