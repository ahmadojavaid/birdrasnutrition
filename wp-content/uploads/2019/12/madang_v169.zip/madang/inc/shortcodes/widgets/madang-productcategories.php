<?php 
echo do_shortcode( '[madang_categories title="'.$instance['title'].'" categories="'.$instance['categories'].'" per_page="'.$instance['per_page'].'" link="'.$instance['link'].'" ]' ); ?>