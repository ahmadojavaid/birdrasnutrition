<?php 
echo do_shortcode( '[madang_promo type="landing" category="'.$instance['category'].'" ]' ); ?>